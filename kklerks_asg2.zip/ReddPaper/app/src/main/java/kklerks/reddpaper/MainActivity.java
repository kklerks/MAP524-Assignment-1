package kklerks.reddpaper;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView postList;
    OpenHelper openHelper;
    ArrayList<String> subReddits;
    ArrayList<String> domains;
    ArrayList<String> titles;
    ArrayList<String> links;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        new LoadArticlesTask().execute();
    }

    @Override
    public void onResume() {
        super.onResume();
        new LoadArticlesTask().execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_subreddits) {
            Intent intent = new Intent(this, SubredditActivity.class);
            startActivity(intent);
        } else if (id == R.id.action_help) {
            Intent intent = new Intent(this, HelpActivity.class);
            startActivity(intent);
        } else if (id == R.id.action_domains) {
            Intent intent = new Intent(this, DomainActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    //Reads all subreddits and domains, then loads articles from all selected subreddits.
    public ArrayList<Article> loadArticles() {
        openHelper = new OpenHelper(this);
        SQLiteDatabase database = openHelper.getReadableDatabase();
        Cursor subCursor = database.rawQuery("SELECT subreddit FROM SubReddits", null);
        subCursor.moveToFirst();
        subReddits = new ArrayList<>();
        while (!subCursor.isAfterLast()) {
            String sub = subCursor.getString(0);
            subReddits.add(sub);
            subCursor.moveToNext();
        }
        subCursor.close();
        Cursor domCursor = database.rawQuery("SELECT domain FROM Domains", null);
        domCursor.moveToFirst();
        domains = new ArrayList<>();
        while (!domCursor.isAfterLast()) {
            String dom = domCursor.getString(0);
            domains.add(dom);
            domCursor.moveToNext();
        }
        domCursor.close();
        database.close();

        ArrayList<Article> articles = new ArrayList<>();

        //Code block responsible for collecting all top current stories, and then selecting top 3.
        for (int i=0;i<subReddits.size();i++) {
            String url = "https://www.reddit.com/r/" + subReddits.get(i) + "/.json";
            ArrayList<Article> subArticles = getArticles(url);

            if (domains.size() > 0) { //Only triggers if user has declared preferred domains for news.
                int articleCount = 0;
                for (int j=0;j<subArticles.size() && articleCount < 3;j++) {
                    for (int k=0;k<domains.size();k++) {
                        if (subArticles.get(j).getDomain().equals(domains.get(k))) {
                            articles.add(subArticles.get(j));
                            subArticles.remove(j);
                            articleCount++;
                        }
                    }
                }
                if (articleCount < 3) {
                    for (int j=0;j<subArticles.size() && articleCount < 3;j++) {
                        articles.add(subArticles.get(j));
                        articleCount++;
                    }
                }
            } else {
                for (int j=0;j<subArticles.size() && j < 3;j++) {
                    articles.add(subArticles.get(j));
                }
            }
        }
        return articles;
    }

    //Gets an entire .json page from Reddit.com, then uses JSONObjects to parse it into an Article class.
    ArrayList<Article> getArticles(String url) {
        ArrayList<Article> articles = new ArrayList<>();
        InputStream is;
        try {
            is = OpenHttpConnection(url);

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));

            String webString = "";
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                webString += line;
            }

            //JSON parsing help provided by:
            //http://stackoverflow.com/questions/24602553/how-to-correctly-parse-reddit-api-in-android
            JSONObject jsonFile = new JSONObject(webString);
            JSONObject allData = jsonFile.getJSONObject("data");
            JSONArray allArticles = allData.getJSONArray("children");
            for (int i=0;i < allArticles.length();i++) {
                JSONObject articleData = allArticles.getJSONObject(i).getJSONObject("data");
                String aDom = articleData.getString("domain");
                String aSub = articleData.getString("subreddit");
                String aUrl = articleData.getString("url");
                String aHead = articleData.getString("title");

                Article article = new Article(aHead,aUrl, aDom, aSub);
                articles.add(article);
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return articles;
    }

    //Sets the adapter for the postList list view on the main page that calls the corresponding link on click.
    public void applyLinks() {
        postList = (ListView) findViewById(R.id.PostList);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.postlist_layout, titles);
        postList.setAdapter(arrayAdapter);

        postList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                String link = links.get(position);
                openLink(link);
            }
        });
    }

    //Opens clicked on link using Intent.
    public void openLink(String link) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        startActivity(intent);
    }

    //HTTP Connection code modified from Lab 7.
    //Connects to the supplied URL and returns an input stream.
    private InputStream OpenHttpConnection(String urlString)
            throws IOException {
        InputStream in = null;
        int response = -1;

        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();

        if (!(conn instanceof HttpURLConnection))
            throw new IOException("Not an HTTP connection");
        try {
            HttpURLConnection httpConn = (HttpURLConnection) conn;
            httpConn.setAllowUserInteraction(false);
            httpConn.setInstanceFollowRedirects(true);
            httpConn.setRequestMethod("GET");
            httpConn.connect();
            response = httpConn.getResponseCode();
            if (response == HttpURLConnection.HTTP_OK) {
                in = httpConn.getInputStream();
            }
        } catch (Exception ex) {
            Log.d("MainActivity", ex.getLocalizedMessage());
            throw new IOException("Error connecting");
        }
        return in;
    }

    //AsyncTask modified from lab 7.
    //Begins loadArticles() and then passes a collection of HTML format links to applyLinks().
    private class LoadArticlesTask extends
            AsyncTask<String, Void, ArrayList<Article>> {
        protected ArrayList<Article> doInBackground(String... urls) {
            return loadArticles();
        }

        protected void onPostExecute(ArrayList<Article> articles) {
            links = new ArrayList<>();
            titles = new ArrayList<>();

            for (int i=0;i<articles.size();i++) {
                String title = articles.get(i).getHeading();
                String url = articles.get(i).getUrl();
                titles.add(title);
                links.add(url);
            }
            applyLinks();
        }
    }
}
