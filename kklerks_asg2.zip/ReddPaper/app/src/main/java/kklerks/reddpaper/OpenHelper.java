package kklerks.reddpaper;

import android.content.Context;
import android.content.res.AssetManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class OpenHelper extends SQLiteOpenHelper {

    static final int DB_CURRENTVERSION = 1;
    static final String DB_FILENAME = "ReddPaper.db";
    Context theContext;

    public OpenHelper(Context context) {
        super(context, DB_FILENAME, null, DB_CURRENTVERSION);
        theContext = context;
    }

    //Reads a default set of subreddits from a text file in Assets. Creates a SubReddit table and a Domain table.
    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE SubReddits (" +
                "_id INTEGER PRIMARY KEY, " +
                "subreddit TEXT)");
        database.execSQL("CREATE TABLE Domains (" +
                "_id INTEGER PRIMARY KEY, " +
                "domain TEXT)");
        AssetManager am = theContext.getAssets();
        try {
            InputStream is = am.open("defaultSubs.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                String insert = "INSERT INTO SubReddits ('subreddit') VALUES ('" +
                        line + "')";
                database.execSQL(insert);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE IF EXISTS SubReddits");
        database.execSQL("DRO PTABLE IF EXISTS Domains");
        this.onCreate(database);
    }
}
