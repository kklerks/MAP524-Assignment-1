package kklerks.reddpaper;

import android.util.Log;

public class Article {
    String heading;
    String url;
    String domain;
    String subreddit;

    public Article(String h, String u, String d, String s) {
        heading = h;
        url = u;
        domain = d;
        subreddit = s;
    }
    public String getHeading() {
        return heading;
    }
    public String getUrl() {
        return url;
    }
    public String getDomain() {
        return domain;
    }
    //Redundant
    public String getSubreddit() {
        return subreddit;
    }

    //A testing function to view the contents of an Article object in the log.
    public void testArticle() {
        Log.d("MainActivity", "Heading: " + heading);
        Log.d("MainActivity", "URL: " + url);
        Log.d("MainActivity", "Domain: " + domain);
        Log.d("MainActivity", "Sub: " + subreddit);
    }
}
