package kklerks.reddpaper;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SubredditActivity extends AppCompatActivity {

    ListView subList;
    OpenHelper openHelper;
    ArrayList<String> subReddits;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subreddit);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        loadSubs();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    //Pulls the list of user's subreddits from the database.
    public void loadSubs() {
        openHelper = new OpenHelper(this);
        SQLiteDatabase database = openHelper.getReadableDatabase();

        Cursor subCursor = database.rawQuery("SELECT subreddit FROM SubReddits", null);
        subCursor.moveToFirst();
        subReddits = new ArrayList<>();
        while (!subCursor.isAfterLast()) {
            String sub = subCursor.getString(0);
            subReddits.add(sub);
            subCursor.moveToNext();
        }
        subCursor.close();
        database.close();
        subList = (ListView) findViewById(R.id.subredditList);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, subReddits);

        subList.setAdapter(arrayAdapter);

        subList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Deleting...", Toast.LENGTH_LONG).show();
                String deletedSub = arrayAdapter.getItem(position);
                deleteSubreddit(deletedSub);
            }
        });
    }

    //Adds a subreddit to the database.
    public void addSubreddit(View v) {
        Toast.makeText(getApplicationContext(), "Adding...", Toast.LENGTH_LONG).show();

        EditText subText = (EditText) findViewById(R.id.editText_subreddit);
        String sub = subText.getText().toString();

        SQLiteDatabase database = openHelper.getWritableDatabase();
        String insert = "INSERT INTO SubReddits ('subreddit') VALUES ('" +
                sub + "')";
        database.execSQL(insert);
        database.close();
        loadSubs();
    }

    //Removes a subreddit from the database when an item on the list is tapped.
    public void deleteSubreddit(String subName) {
        SQLiteDatabase database = openHelper.getWritableDatabase();
        String delete = "DELETE FROM SubReddits WHERE subReddit = '" + subName + "'";
        database.execSQL(delete);
        database.close();
        loadSubs();
    }
}
