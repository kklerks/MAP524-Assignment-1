package kklerks.reddpaper;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DomainActivity extends AppCompatActivity {
    ListView domList;
    OpenHelper openHelper;
    ArrayList<String> domains;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domain);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        loadDomains();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    //Loads a list of user's saved domains from the database to display on the listview.
    public void loadDomains() {
        openHelper = new OpenHelper(this);
        SQLiteDatabase database = openHelper.getReadableDatabase();

        Cursor domCursor = database.rawQuery("SELECT domain FROM Domains", null);
        domCursor.moveToFirst();
        domains = new ArrayList<>();
        while (!domCursor.isAfterLast()) {
            String dom = domCursor.getString(0);
            domains.add(dom);
            domCursor.moveToNext();
        }
        domCursor.close();
        database.close();
        domList = (ListView) findViewById(R.id.domainList);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, domains);

        domList.setAdapter(arrayAdapter);

        domList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Deleting...", Toast.LENGTH_LONG).show();
                String deletedDom = arrayAdapter.getItem(position);
                deleteDomain(deletedDom);
            }
        });
    }

    //Adds a new domain to the database from the editText box.
    public void addDomain(View v) {
        Toast.makeText(getApplicationContext(), "Adding...", Toast.LENGTH_LONG).show();

        EditText domText = (EditText) findViewById(R.id.editText_domain);
        String dom = domText.getText().toString();
        domText.setText("");

        SQLiteDatabase database = openHelper.getWritableDatabase();
        String insert = "INSERT INTO Domains ('domain') VALUES ('" +
                dom + "')";
        database.execSQL(insert);
        database.close();
        loadDomains();
    }

    //Deletes a domain from the database when the user taps an item.
    public void deleteDomain(String domName) {
        SQLiteDatabase database = openHelper.getWritableDatabase();
        String delete = "DELETE FROM Domains WHERE domain = '" + domName + "'";
        database.execSQL(delete);
        database.close();
        loadDomains();
    }
}
